=== Unsereuni Online Demo Austria ===
Contributors: Simon Repp, Andreas Demmelbauer und Thomas Lohninger (based on Ralf "Arby" Brostedt, Helge Fahrnberger and Robert Harm)
Tags: akvorrat, vds, protests, data retention, freedom, fear
Requires at least: 2.x
Tested up to: 3.2.1
Stable tag: 10

Eselsohr zur Unterstützung der Bürgerinitiative gegen die Vorratsdatenspeicherung und zur Evaluierung sämtlicher Terrorgesetzte.

== Description ==

Unterstützte die Bürgerinitiative gegen die Vorratsdatenspeicherung und zur Evaluierung sämtlicher Terrorgesetzte, indem du dieses Eselsohr auf deinem Blog installierst! 
Informationen zur Bürgerinitiative findest du auf http://zeichnemit.at
und über den Twitter Account http://twitter.com/akvorrat_at
Dies ist eine Aktion des AK Vorrat Österreich http://akvorrat.at

BITTE TRAGT EUCH IN DIESER LISTE EIN WENN IHR AN DEM PROTEST TEILNEHMT UND DAS ESELSOHR AUF EURER SEITE INSTALLIERT!!!11elf
http://wiki.akvorrat.at/doku.php?id=onlinedemo

== Installation ==

1. Upload `akvorrat-demo-austria.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

This plugin is based on VDS Page Peel, which was originally developed by Ralf "Arby" Brostedt and is a fork of the branch of the unibrennt pagepeel.

== Screenshots ==

1. akvorrat-pagepeel2.jpg
2. akvorrat-pagepeel2.jpg

== Changelog ==

v1.0 - Initial Release
